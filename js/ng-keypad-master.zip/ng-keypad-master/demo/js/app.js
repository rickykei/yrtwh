/**
 * @overview
 * @copyright 2013 Tommy Rochette http://trochette.github.com/
 * @author Tommy Rochette
 * @version 0.0.1
 *
 * @license MIT
 */
(function(){
    'use strict';
    angular.module('app',['ngKeypad','ngDraggable']);
})();

